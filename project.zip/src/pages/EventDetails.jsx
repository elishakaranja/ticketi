function EventDetails() {
    return (
      <div>
        <h1>Event Name</h1>
        <p>Date: TBD</p>
        <p>Location: TBD</p>
        <p>Price: TBD</p>
        <button>Buy Ticket</button>
      </div>
    );
  }
  
  export default EventDetails;
  