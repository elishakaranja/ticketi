function Home() {
    return (
      <div>
        <h1>Welcome to the Event Ticketing System</h1>
        <p>Find and buy tickets for amazing events!</p>
      </div>
    );
  }
  
  export default Home;
  