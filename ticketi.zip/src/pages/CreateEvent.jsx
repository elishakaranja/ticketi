import { useState} from "react";
import "./CreateEvent.module.css";
function CreateEvent(){
    const[formData, setFormData] = useState({
        //creating objects with empty values for each field
        name: "",
        description: "",
        location: "",
        data: "",
        price: "",
        image: ""


    });

    

function handleChange(event){
    const {name, value} = event.target;
    setFormData({...formData,[name]: value});
}

function handleSubmit(event) {
    event.preventDefault();
    console.log("Event Data:", formData);

}




    return (
    <div className={styles.container}>
      <h1>Create Event</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Event Name" value={formData.name} onChange={handleChange} required />
        <textarea name="description" placeholder="Event Description" value={formData.description} onChange={handleChange} required></textarea>
        <input type="text" name="location" placeholder="Location" value={formData.location} onChange={handleChange} required />
        <input type="date" name="date" value={formData.date} onChange={handleChange} required />
        <input type="number" name="price" placeholder="Ticket Price" value={formData.price} onChange={handleChange} required />
        <input type="text" name="image" placeholder="Image URL" value={formData.image} onChange={handleChange} />
        <button type="submit">Create Event</button>
      </form>
    </div>
    );
}

export default CreateEvent;